package com.company;

public class BST <E extends Comparable<Object>>  {

    class Node <E>{
        E key;
        Node left, right;

        public Node(E item) {
            key = item;
            left = right = null;
        }
        public E getKey() {
            return key;
        }

        public void setKey(E key) {
            this.key = key;
        }

        public Node getLeft() {
            return left;
        }

        public Node getRight() {
            return right;
        }
    }

    Node root;

    BST() {
        root = null;
    }

    public Node getRoot() {
        return root;
    }

    public void setRoot(Node root) {
        this.root = root;
    }

    public void insert(E data) {
        root = insertRec(root, data);
    }

    Node insertRec(Node root, E key) {

        /* If the tree is empty, return a new node */
        if (root == null) {
            root = new Node(key);
            return root;
        }

        /* Otherwise, recur down the tree */
        if (key.compareTo((E) root.key)==-1)
            root.left = insertRec(root.left, key);
        else if (key .compareTo((E) root.key)==1)
            root.right = insertRec(root.right, key);

        /* return the (unchanged) node pointer */
        return root;
    }

    // This method mainly calls InorderRec()
    public void print() {
        System.out.println("BST:");
        inorderRec(root);
    }

    public  Node minimumKey(Node curr)
    {
        while(curr.left != null) {
            curr = curr.left;
        }
        return curr;
    }

//    public boolean delete(String value){
//        deleteNode(getRoot(),value);
//        return true;
//    }
    // Function to delete node from a BST
//    public Node deleteNode(Node root, String key)
//    {
//        // pointer to store parent node of current node
//        Node parent = null;
//
//        // start with root node
//        Node curr = root;
//
//        // search key in BST and set its parent pointer
//        while (curr != null && ! curr.getKey().equals(key) )
//        {
//            // update parent node as current node
//            parent = curr;
//
//            // if given key is less than the current node, go to left subtree
//            // else go to right subtree
//            if (((E)curr.getKey()).compareTo(key)==1) {
//                curr = curr.getLeft();
//            }
//            else {
//                curr = curr.getRight();
//            }
//        }
//
//        // return if key is not found in the tree
//        if (curr == null) {
//            return root;
//        }
//
//        // Case 1: node to be deleted has no children i.e. it is a leaf node
//        if (curr.left == null && curr.right == null)
//        {
//            // if node to be deleted is not a root node, then set its
//            // parent left/right child to null
//            if (curr != root) {
//                if (parent.left == curr) {
//                    parent.left = null;
//                } else {
//                    parent.right = null;
//                }
//            }
//            // if tree has only root node, delete it and set root to null
//            else {
//                root = null;
//            }
//        }
//
//        // Case 2: node to be deleted has two children
//        else if (curr.left != null && curr.right != null)
//        {
//            // find its in-order successor node
//            Node successor  = minimumKey(curr.right);
//
//            // store successor value
//            E val = (E)successor.getKey();
//
//            // recursively delete the successor. Note that the successor
//            // will have at-most one child (right child)
//            deleteNode(root, successor.getKey());
//
//            // Copy the value of successor to current node
//            curr.setKey(val);
//        }
//
//        // Case 3: node to be deleted has only one child
//        else
//        {
//            // find child node
//            Node child = (curr.left != null)? curr.left: curr.right;
//
//            // if node to be deleted is not a root node, then set its parent
//            // to its child
//            if (curr != root)
//            {
//                if (curr == parent.left) {
//                    parent.left = child;
//                } else {
//                    parent.right = child;
//                }
//            }
//
//            // if node to be deleted is root node, then set the root to child
//            else {
//                root = child;
//            }
//        }
//
//        return root;
//    }
//
//













    public E search(String value){
        return recursiveSearch(getRoot(),value);
    }

    public E recursiveSearch(Node node, String value){
//        if(node==null)
//            return null;
//        if(node.getKey().equals(value))
//            return (E) node.getKey();
//        else if (recursiveSearch(node.getLeft(),value)!=null)
//            return recursiveSearch(node.getLeft(),value);
//        else
//            return recursiveSearch(node.getRight(),value);
        return null;
    }
    // A utility function to do inorder traversal of BST
    void inorderRec(Node root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.println(root.key);
            inorderRec(root.right);
        }
    }

}